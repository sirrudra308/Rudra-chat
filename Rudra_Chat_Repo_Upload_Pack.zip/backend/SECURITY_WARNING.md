# Security Warning — Starter API

The current FastAPI routes are for local prototyping only. Some routes accept a `user_id` in the request and do not yet verify an authenticated identity or permission. Do not expose this API to the public internet, connect it to real wallets, or use it for real-money payouts.

Before any staging environment: implement authentication, authorization, request validation, rate limits, audit logging, migration-based schema changes, secret management, and automated security tests. For production wallet operations, enforce server-side transactions, idempotency keys and double-entry accounting; clients must never set balances.
