-- PostgreSQL foundation schema. Apply with a migration tool in production.
CREATE TABLE IF NOT EXISTS users (
  id BIGSERIAL PRIMARY KEY,
  display_name VARCHAR(60) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended','deleted')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS rooms (
  id BIGSERIAL PRIMARY KEY,
  title VARCHAR(100) NOT NULL,
  owner_user_id BIGINT NOT NULL REFERENCES users(id),
  room_type VARCHAR(20) NOT NULL DEFAULT 'party' CHECK (room_type IN ('party','gaming')),
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS room_seats (
  id BIGSERIAL PRIMARY KEY,
  room_id BIGINT NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  seat_no SMALLINT NOT NULL CHECK (seat_no BETWEEN 1 AND 16),
  user_id BIGINT REFERENCES users(id),
  is_muted BOOLEAN NOT NULL DEFAULT true,
  UNIQUE(room_id, seat_no)
);
CREATE TABLE IF NOT EXISTS wallets (
  user_id BIGINT PRIMARY KEY REFERENCES users(id),
  coin_balance BIGINT NOT NULL DEFAULT 0 CHECK (coin_balance >= 0)
);
CREATE TABLE IF NOT EXISTS ledger_entries (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id),
  amount BIGINT NOT NULL,
  entry_type VARCHAR(30) NOT NULL,
  reference_id VARCHAR(100) NOT NULL UNIQUE,
  note VARCHAR(250) NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- Never let clients write coin balances directly. Implement ledger + wallet changes in one DB transaction.
-- Payment provider webhooks must be signature-verified and idempotent before crediting coins.
