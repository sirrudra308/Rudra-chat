# Rudra Chat API — development starter

## Run locally
1. Install Docker Desktop / Docker Engine.
2. From the project root run `docker compose up --build`.
3. Open `http://localhost:8000/docs` for the API explorer and `http://localhost:8000/health` for health status.

Tables are auto-created only because this compose file explicitly sets `AUTO_CREATE_TABLES=true`. Use migrations for production.

## Included endpoints
- `GET /health`
- `GET /v1/ready`
- `GET /v1/rooms`
- `POST /v1/rooms`
- `GET /v1/rooms/{room_id}/seats`
- `POST /v1/rooms/{room_id}/seats/{seat_no}/claim`
- `GET /v1/wallets/{user_id}`

## Important limitations
This is a development scaffold, not a production backend. Authentication/authorization, OTP, room membership enforcement, WebSocket events, voice RTC provider, payment provider, signed webhooks, coin/gift transfer transactions, agency commissions, payout workflows, rate limits, observability, migrations and tests still need implementation and security review. Do not expose it publicly or use real money with this version. Never seed or change real coin balances through client requests.
