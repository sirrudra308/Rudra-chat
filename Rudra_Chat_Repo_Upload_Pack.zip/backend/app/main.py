from contextlib import asynccontextmanager
from fastapi import Depends, FastAPI, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from .db import Base, engine, get_db
from .models import Room, RoomSeat, User, Wallet

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Local starter convenience. Production should use versioned migrations instead.
    if __import__('os').environ.get('AUTO_CREATE_TABLES', 'false').lower() == 'true':
        Base.metadata.create_all(bind=engine)
    yield

app = FastAPI(title="Rudra Chat API", version="0.1.0", lifespan=lifespan)

class RoomCreate(BaseModel):
    title: str = Field(min_length=2, max_length=100)
    owner_user_id: int = Field(gt=0)
    room_type: str = Field(default="party", pattern="^(party|gaming)$")

class SeatClaim(BaseModel):
    user_id: int = Field(gt=0)

@app.get('/health')
def health():
    return {"status": "ok", "app": "Rudra Chat API", "environment": "development"}

@app.get('/v1/rooms')
def list_rooms(db: Session = Depends(get_db)):
    rooms = db.scalars(select(Room).where(Room.is_active.is_(True)).order_by(Room.id.desc()).limit(100)).all()
    return [{"id": r.id, "title": r.title, "owner_user_id": r.owner_user_id, "room_type": r.room_type} for r in rooms]

@app.post('/v1/rooms', status_code=201)
def create_room(payload: RoomCreate, db: Session = Depends(get_db)):
    owner = db.get(User, payload.owner_user_id)
    if not owner:
        raise HTTPException(404, "Owner user not found. Create the user through the authenticated user service first.")
    room = Room(title=payload.title, owner_user_id=payload.owner_user_id, room_type=payload.room_type)
    db.add(room)
    db.flush()
    db.add_all([RoomSeat(room_id=room.id, seat_no=n) for n in range(1, 17)])
    db.commit()
    return {"id": room.id, "title": room.title, "room_type": room.room_type, "seat_count": 16}

@app.get('/v1/rooms/{room_id}/seats')
def room_seats(room_id: int, db: Session = Depends(get_db)):
    if not db.get(Room, room_id):
        raise HTTPException(404, "Room not found")
    seats = db.scalars(select(RoomSeat).where(RoomSeat.room_id == room_id).order_by(RoomSeat.seat_no)).all()
    return [{"seat_no": s.seat_no, "user_id": s.user_id, "is_muted": s.is_muted} for s in seats]

@app.post('/v1/rooms/{room_id}/seats/{seat_no}/claim')
def claim_seat(room_id: int, seat_no: int, payload: SeatClaim, db: Session = Depends(get_db)):
    """Starter-only seat claim. Add auth/room membership checks before production use."""
    if seat_no < 1 or seat_no > 16:
        raise HTTPException(422, "Seat number must be 1–16")
    if not db.get(User, payload.user_id):
        raise HTTPException(404, "User not found")
    seat = db.scalar(select(RoomSeat).where(RoomSeat.room_id == room_id, RoomSeat.seat_no == seat_no).with_for_update())
    if not seat:
        raise HTTPException(404, "Room or seat not found")
    if seat.user_id is not None:
        raise HTTPException(409, "Seat is already occupied")
    seat.user_id = payload.user_id
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "Seat claim conflict; refresh and try again")
    return {"room_id": room_id, "seat_no": seat_no, "user_id": payload.user_id, "status": "claimed"}

@app.get('/v1/wallets/{user_id}')
def wallet_summary(user_id: int, db: Session = Depends(get_db)):
    """Read-only demo route; production must authorize the wallet owner/admin."""
    wallet = db.get(Wallet, user_id)
    if not wallet:
        return {"user_id": user_id, "coin_balance": 0, "note": "No wallet created yet"}
    return {"user_id": user_id, "coin_balance": wallet.coin_balance}

@app.get('/v1/ready')
def readiness(db: Session = Depends(get_db)):
    try:
        db.execute(text('SELECT 1'))
        return {"api": "ready", "database": "connected"}
    except Exception as exc:
        raise HTTPException(503, "Database unavailable") from exc
