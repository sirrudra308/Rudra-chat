from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_env: str = "development"
    database_url: str = "postgresql+psycopg://rudra:change-this-password@localhost:5432/rudra_chat"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
