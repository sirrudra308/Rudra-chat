# Rudra Chat — चरण 4: Android Build + Server Setup

## इस पैक में क्या है
- `.github/workflows/android-debug-apk.yml`: GitHub Actions में Android debug APK बनाने का workflow.
- `flutter_app/lib/main.dart`: ऐप में API base URL, `/health` connection check और `/v1/rooms` पढ़ने की स्क्रीन.
- `flutter_app/pubspec.yaml`: HTTP client dependency.
- `backend/` और `docker-compose.yml`: स्थानीय development API + PostgreSQL scaffold.

## APK बनाने का तरीका (GitHub Actions)
1. ZIP को extract करें और पूरे `rudra_chat_starter` फ़ोल्डर को अपने GitHub repository में upload/push करें.
2. GitHub में repository खोलें → **Actions** → **Build Android debug APK** → **Run workflow**.
3. Workflow के सभी steps हरे होने के बाद run page के **Artifacts** हिस्से से `rudra-chat-debug-apk` डाउनलोड करें.
4. ZIP artifact खोलकर `app-debug.apk` निकालें और अपने Android test phone पर install करें. Android की अनुमति मांगे तो केवल अपने बनाए test APK के लिए install की अनुमति दें.

यह debug/test APK होगा, signed production release नहीं. GitHub account/repository और workflow run उपयोगकर्ता के खाते में होना जरूरी है; इस चैट से उसे push या run नहीं किया जा सकता.

## लोकल सर्वर चलाना
Docker Engine/Desktop इंस्टॉल होने के बाद project root में:

```bash
docker compose up --build
```

फिर उसी कंप्यूटर पर `http://localhost:8000/health` और `http://localhost:8000/docs` खोलें. Docker/Flutter इस कार्य वातावरण में उपलब्ध नहीं हैं, इसलिए यहाँ वास्तविक container launch या APK compilation सत्यापित नहीं किया गया.

## फोन से API कनेक्ट करना
- Emulator में host computer का API सामान्यतः `http://10.0.2.2:8000` से उपलब्ध होता है.
- असली फोन पर `10.0.2.2` इस्तेमाल न करें. उसी Wi-Fi पर कंप्यूटर का LAN IP दें, या deployed HTTPS URL दें.
- इंटरनेट पर दोस्तों से जोड़ने से पहले public HTTPS hosting, authentication/authorization, rate limiting, migrations, monitoring और security review अनिवार्य हैं.

## सुरक्षा चेतावनी — सार्वजनिक सर्वर अभी deploy न करें
यह backend अभी development scaffold है. कुछ endpoints authenticated नहीं हैं; wallet, room और seat routes production-grade authorization के बिना हैं. इसे सीधे public internet पर expose न करें और real money/real paid coins इस्तेमाल न करें. पहले login/OTP, server-side roles, audit logs, rate limits और automated security tests जोड़ने होंगे.

## अभी क्या नहीं जुड़ा
LiveKit/Agora voice, real-time chat/WebSockets, phone OTP, Google/Apple sign-in, multiplayer games, payment billing, production coin/gift transactions, signed release keystore और store publishing.
