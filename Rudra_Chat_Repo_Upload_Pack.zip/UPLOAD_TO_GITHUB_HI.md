# Rudra Chat — GitHub Upload Guide (Hindi)

Aapki pehle wali repository ZIP mein sirf README tha. Yeh package actual starter source files aur Android debug APK GitHub Actions workflow rakhta hai.

## Repository mein files kaise daalein
1. Is ZIP ko extract karein.
2. Extract hue folder ke andar ki sabhi files/folders (jaise `.github`, `flutter_app`, `backend`, `README.md`) repository ke root mein upload karein. Sirf ZIP ko repository mein rakhne se workflow khud se active nahi hota.
3. GitHub par `.github/workflows/android-debug-apk.yml` file ka hona zaroori hai.
4. Commit changes karein. GitHub Actions tab mein `Build Android debug APK` workflow check karein.
5. Build successful ho to run ke Artifacts section se `rudra-chat-debug-apk` download karein. Us ZIP ke andar `app-debug.apk` hoga.

## Zaroori sachchai
- Yeh starter/test build hai, production-ready app nahi.
- Live voice, verified OTP/login, production backend deployment, multiplayer game logic, moderation, and real payments abhi configured nahi hain.
- APK sirf tab milega jab GitHub Actions ka build successful ho. Is package se build run hone ka abhi daawa nahi kiya ja raha.
