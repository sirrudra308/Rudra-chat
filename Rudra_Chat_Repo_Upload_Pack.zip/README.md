# Rudra Chat — Starter Prototype

This package contains:
- A clickable browser prototype (`prototype/index.html`) with Home, Party Room, Quiz, Wallet, Agency, and Profile views.
- A Flutter starter app (`flutter_app/`) with a dark navy / royal violet / gold theme and bottom navigation.
- A product structure and implementation notes.

## Important
This is a **UI prototype / starter source**, not a production-ready social app. It does not yet include live voice, real multiplayer networking, real payments, coin purchases, authentication, backend APIs, or real host payouts. Those need a backend, provider accounts, testing, and security review.

## Preview the clickable prototype
Open `prototype/index.html` in a browser. No build step is required.

## Run the Flutter starter
1. Install Flutter SDK and Android Studio / Xcode as appropriate.
2. From this folder run:
   ```bash
   cd flutter_app
   flutter pub get
   flutter run
   ```
3. To build Android:
   ```bash
   flutter build apk
   ```
4. For iOS, use macOS with Xcode:
   ```bash
   flutter build ios
   ```

The Flutter project uses only Flutter SDK widgets and has no third-party package dependencies yet.

## Suggested next implementation stages
1. Add backend API and authentication.
2. Integrate a real-time audio SDK and server-issued voice tokens.
3. Implement server-authoritative quiz matches.
4. Implement a transactional wallet ledger and verified payment webhooks.
5. Implement agency approval, host earnings, commissions, admin audit logs, and payout compliance.
6. Add reporting/blocking, account deletion, privacy policy, automated tests, and store compliance checks.

## Store release preparation pack
See `store_release/` for owner decisions, provider selection notes, a coin/commission proposal, release blockers, draft store listing, privacy-policy template, community guidelines and submission checklist. These documents are templates; fill and legally review them against the actual shipped app before publishing.


## Owner setup snapshot (2026-10-25)
Publisher preference: individual; Play Console and Apple Developer accounts not yet created; target login is phone OTP plus Google/Apple; voice/payment provider not selected; money payouts intended but not approved; global launch ambition; intended minimum age 18+; support email supplied as `sirrudra308@gmail.com`; no public privacy domain yet. See `store_release/OWNER_DECISIONS.md`.
