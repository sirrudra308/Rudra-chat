import 'package:flutter_test/flutter_test.dart';
import 'package:rudra_chat/main.dart';

void main() {
  testWidgets('Rudra Chat home screen renders', (WidgetTester tester) async {
    await tester.pumpWidget(const RudraChatApp());
    expect(find.text('Rudra Chat'), findsOneWidget);
    expect(find.text('Trending rooms'), findsOneWidget);
  });
}
