import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

/// Test-only API console. Configure with:
/// flutter run --dart-define=RUDRA_API_BASE=http://10.0.2.2:8000
/// For a physical phone, use the computer's reachable LAN IP, not 10.0.2.2.
class ApiConsolePage extends StatefulWidget {
  const ApiConsolePage({super.key});
  @override
  State<ApiConsolePage> createState() => _ApiConsolePageState();
}

class _ApiConsolePageState extends State<ApiConsolePage> {
  static const configuredBase = String.fromEnvironment('RUDRA_API_BASE', defaultValue: 'http://10.0.2.2:8000');
  late final TextEditingController base = TextEditingController(text: configuredBase);
  final name = TextEditingController(text: 'Rudra Tester');
  final roomTitle = TextEditingController(text: 'Friends Room');
  final joinRoomId = TextEditingController();
  final userIdInput = TextEditingController();
  String userId = '';
  String roomId = '';
  String status = 'Not connected yet. Start the backend and tap Check server.';
  bool busy = false;
  List<dynamic> rooms = [];
  Map<String, dynamic>? wallet;

  Uri endpoint(String path) {
    final b = base.text.trim().replaceAll(RegExp(r'/+$'), '');
    return Uri.parse('$b$path');
  }

  Future<Map<String, dynamic>> request(String method, String path, {Map<String, dynamic>? body}) async {
    final uri = endpoint(path);
    final headers = {'Content-Type': 'application/json'};
    late http.Response response;
    if (method == 'GET') {
      response = await http.get(uri, headers: headers).timeout(const Duration(seconds: 8));
    } else {
      response = await http.post(uri, headers: headers, body: jsonEncode(body ?? {})).timeout(const Duration(seconds: 8));
    }
    dynamic data;
    try { data = jsonDecode(response.body); } catch (_) { data = {'detail': response.body}; }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(data is Map ? (data['detail'] ?? 'HTTP ${response.statusCode}') : 'HTTP ${response.statusCode}');
    }
    if (data is Map<String, dynamic>) return data;
    throw Exception('Unexpected server response');
  }

  Future<void> runAction(Future<void> Function() action) async {
    if (busy) return;
    setState(() { busy = true; status = 'Working…'; });
    try { await action(); }
    catch (e) { if (mounted) setState(() => status = 'Error: ${e.toString().replaceFirst('Exception: ', '')}'); }
    finally { if (mounted) setState(() => busy = false); }
  }

  Future<void> checkServer() async => runAction(() async {
    final data = await request('GET', '/health');
    setState(() => status = 'Connected • ${data['mode'] ?? 'API'} • production_ready=${data['production_ready']}');
  });

  Future<void> createUser() async => runAction(() async {
    final data = await request('POST', '/users', body: {'display_name': name.text.trim()});
    setState(() { userId = data['user_id'].toString(); userIdInput.text = userId; status = 'Test user created: $userId'; });
    await refreshWallet(silent: true);
  });

  Future<void> refreshRooms() async => runAction(() async {
    final data = await request('GET', '/rooms');
    setState(() { rooms = (data['rooms'] as List? ?? []); status = 'Loaded ${rooms.length} room(s) from server.'; });
  });

  Future<void> createRoom() async => runAction(() async {
    final uid = (userIdInput.text.trim().isNotEmpty ? userIdInput.text.trim() : userId);
    if (uid.isEmpty) throw Exception('Create a test user first, then use their ID.');
    final data = await request('POST', '/rooms', body: {'title': roomTitle.text.trim(), 'owner_id': uid, 'description': 'Rudra Chat API-connected test room'});
    setState(() { roomId = data['room_id'].toString(); joinRoomId.text = roomId; status = 'Room created: $roomId'; });
    final list = await request('GET', '/rooms');
    setState(() => rooms = (list['rooms'] as List? ?? []));
  });

  Future<void> joinRoom(String id) async => runAction(() async {
    final uid = (userIdInput.text.trim().isNotEmpty ? userIdInput.text.trim() : userId);
    if (uid.isEmpty) throw Exception('Create a test user first, then use their ID.');
    final data = await request('POST', '/rooms/${Uri.encodeComponent(id)}/join', body: {'user_id': uid});
    setState(() => status = 'Joined ${data['room_id']} • members: ${data['member_count']}');
  });

  Future<void> refreshWallet({bool silent = false}) async {
    final uid = (userIdInput.text.trim().isNotEmpty ? userIdInput.text.trim() : userId);
    if (uid.isEmpty) { if (!silent) throw Exception('Enter or create a user ID first.'); return; }
    final data = await request('GET', '/wallet/${Uri.encodeComponent(uid)}');
    if (mounted) setState(() { wallet = data; if (!silent) status = 'Wallet loaded from server for $uid'; });
  }

  @override
  void dispose() { base.dispose(); name.dispose(); roomTitle.dispose(); joinRoomId.dispose(); userIdInput.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Rudra Chat • API Test')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Stage 3 — Flutter to API connection', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      const Text('Test mode only: this API has no OTP/login yet. Do not use real money or production user data.'),
      const SizedBox(height: 14),
      TextField(controller: base, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'API base URL', hintText: 'http://10.0.2.2:8000', border: OutlineInputBorder())),
      const SizedBox(height: 8),
      FilledButton.icon(onPressed: busy ? null : checkServer, icon: const Icon(Icons.cloud_done), label: const Text('Check server')),
      Card(color: Theme.of(context).colorScheme.surfaceContainerHighest, child: Padding(padding: const EdgeInsets.all(12), child: Text(status))),
      const Divider(height: 28),
      const Text('1. Test user', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      TextField(controller: name, decoration: const InputDecoration(labelText: 'Display name', border: OutlineInputBorder())),
      const SizedBox(height: 8),
      FilledButton(onPressed: busy ? null : createUser, child: const Text('Create test user on server')),
      TextField(controller: userIdInput, decoration: const InputDecoration(labelText: 'Current / other user ID', helperText: 'Use the generated ID here; a friend needs their own ID.', border: OutlineInputBorder())),
      const Divider(height: 28),
      const Text('2. Rooms', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      TextField(controller: roomTitle, decoration: const InputDecoration(labelText: 'New room title', border: OutlineInputBorder())),
      const SizedBox(height: 8),
      FilledButton(onPressed: busy ? null : createRoom, child: const Text('Create room on server')),
      const SizedBox(height: 6),
      OutlinedButton(onPressed: busy ? null : refreshRooms, child: const Text('Refresh room list')),
      if (rooms.isEmpty) const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Text('No rooms loaded yet.')),
      ...rooms.map((r) => Card(child: ListTile(title: Text('${r['title'] ?? 'Room'}'), subtitle: Text('${r['room_id']} • members ${r['member_count'] ?? 0}'), trailing: IconButton(tooltip: 'Join room', icon: const Icon(Icons.login), onPressed: busy ? null : () => joinRoom(r['room_id'].toString()))))),
      TextField(controller: joinRoomId, decoration: const InputDecoration(labelText: 'Room ID to join', border: OutlineInputBorder())),
      OutlinedButton(onPressed: busy ? null : () => joinRoom(joinRoomId.text.trim()), child: const Text('Join by room ID')),
      const Divider(height: 28),
      const Text('3. Server wallet', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      OutlinedButton(onPressed: busy ? null : () => runAction(() => refreshWallet()), child: const Text('Load wallet from server')),
      if (wallet != null) Card(child: ListTile(leading: const Icon(Icons.account_balance_wallet), title: Text('Balance: ${wallet!['balance']} coins'), subtitle: Text('User: ${wallet!['user_id']} • transactions: ${(wallet!['transactions'] as List? ?? []).length}'))),
      const SizedBox(height: 16),
      const Text('Not included yet: phone OTP, real authentication, live voice, real-time chat, push notifications, production hosting and APK build.', style: TextStyle(fontSize: 12)),
    ]),
  );
}
