import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const RudraChatApp());

const _navy = Color(0xFF111426);
const _panel = Color(0xFF1A1D33);
const _panel2 = Color(0xFF242744);
const _violet = Color(0xFF6B5BD2);
const _gold = Color(0xFFD9AF61);
const _muted = Color(0xFFA9ADC8);

class RudraChatApp extends StatelessWidget {
  const RudraChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = ColorScheme.fromSeed(
      seedColor: _violet,
      brightness: Brightness.dark,
      surface: _panel,
    );
    return MaterialApp(
      title: 'Rudra Chat',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: scheme,
        scaffoldBackgroundColor: _navy,
        cardTheme: const CardThemeData(
          color: _panel,
          margin: EdgeInsets.zero,
          elevation: 0,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: _navy,
          foregroundColor: Colors.white,
          centerTitle: false,
        ),
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;

  final _pages = const [
    HomeScreen(),
    PartyScreen(),
    QuizScreen(),
    WalletScreen(),
    AgencyScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: _index, children: _pages)),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF15172A),
        indicatorColor: _violet.withValues(alpha: .25),
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.mic_none), label: 'Party'),
          NavigationDestination(icon: Icon(Icons.quiz_outlined), label: 'Quiz'),
          NavigationDestination(icon: Icon(Icons.toll_outlined), label: 'Wallet'),
          NavigationDestination(icon: Icon(Icons.groups_outlined), label: 'Agency'),
        ],
      ),
    );
  }
}

class BrandHeader extends StatelessWidget {
  const BrandHeader({super.key, this.showBalance = true});
  final bool showBalance;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            gradient: const LinearGradient(colors: [_violet, Color(0xFF332657)]),
          ),
          alignment: Alignment.center,
          child: const Text('R', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: _gold)),
        ),
        const SizedBox(width: 11),
        const Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Rudra Chat', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            Text('Your voice. Your people. Your game.', style: TextStyle(fontSize: 11, color: _muted)),
          ]),
        ),
        if (showBalance)
          const Chip(
            avatar: Icon(Icons.toll, size: 17, color: _gold),
            label: Text('9,000'),
            side: BorderSide(color: Color(0xFF4B4568)),
            backgroundColor: Color(0xFF292343),
          ),
      ],
    );
  }
}

class ScreenFrame extends StatelessWidget {
  const ScreenFrame({super.key, required this.child, this.padding = const EdgeInsets.fromLTRB(16, 16, 16, 24)});
  final Widget child;
  final EdgeInsets padding;

  @override
  Widget build(BuildContext context) => Padding(
    padding: padding,
    child: SingleChildScrollView(child: child),
  );
}

class HeroCard extends StatelessWidget {
  const HeroCard({super.key, required this.title, required this.subtitle, this.actionLabel, this.onAction});
  final String title;
  final String subtitle;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(19),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(22),
      border: Border.all(color: const Color(0xFF50466F)),
      gradient: const RadialGradient(
        center: Alignment.topRight,
        radius: 1.4,
        colors: [Color(0xFF514099), Color(0xFF292449), Color(0xFF20223A)],
      ),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Chip(label: Text('✦ PARTY · PLAY · CONNECT'), backgroundColor: Color(0xFF30294B)),
      const SizedBox(height: 8),
      Text(title, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w800)),
      const SizedBox(height: 7),
      Text(subtitle, style: const TextStyle(color: Color(0xFFD1CCE8), height: 1.45)),
      if (actionLabel != null) ...[
        const SizedBox(height: 15),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: _gold, foregroundColor: const Color(0xFF211B12)),
          onPressed: onAction,
          child: Text(actionLabel!),
        ),
      ],
    ]),
  );
}

class SectionHeading extends StatelessWidget {
  const SectionHeading(this.title, {super.key, this.trailing});
  final String title;
  final String? trailing;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(top: 21, bottom: 11),
    child: Row(children: [
      Expanded(child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
      if (trailing != null) Text(trailing!, style: const TextStyle(color: _muted, fontSize: 12)),
    ]),
  );
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) => ScreenFrame(
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const BrandHeader(),
      const SizedBox(height: 20),
      HeroCard(
        title: 'Find your people.',
        subtitle: 'Join a live room, share your voice, and challenge friends in a quiz.',
        actionLabel: 'Explore Party Rooms',
        onAction: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Prototype only — room navigation is available from the Party tab.'))),
      ),
      const SizedBox(height: 12),
      SizedBox(
        width: double.infinity,
        child: OutlinedButton.icon(
          icon: const Icon(Icons.cloud_sync_outlined),
          label: const Text('Connect to Rudra Chat server'),
          onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ApiConnectionScreen())),
        ),
      ),
      const SectionHeading('Quick access'),
      const Row(children: [
        Expanded(child: QuickTile(icon: Icons.mic, title: 'Party Room')),
        SizedBox(width: 9),
        Expanded(child: QuickTile(icon: Icons.quiz, title: 'Quiz Arena')),
        SizedBox(width: 9),
        Expanded(child: QuickTile(icon: Icons.groups, title: 'Agency')),
      ]),
      const SectionHeading('Trending rooms', trailing: 'DEMO DATA'),
      const RoomCard(icon: Icons.music_note, title: 'Late Night Lounge', subtitle: 'Host: Rudra Star · 128 listening'),
      const SizedBox(height: 10),
      const RoomCard(icon: Icons.graphic_eq, title: 'Music & Masti', subtitle: 'Host: Jasmine · 76 listening'),
      const SectionHeading('Today’s challenge'),
      const RoomCard(icon: Icons.emoji_events, title: 'Quick Quiz Challenge', subtitle: '10 questions · Friends leaderboard'),
      const SizedBox(height: 18),
      const Text('Demo UI only. Live services are not connected.', style: TextStyle(color: _muted, fontSize: 12)),
    ]),
  );
}

class ApiConnectionScreen extends StatefulWidget {
  const ApiConnectionScreen({super.key});

  @override
  State<ApiConnectionScreen> createState() => _ApiConnectionScreenState();
}

class _ApiConnectionScreenState extends State<ApiConnectionScreen> {
  final _urlController = TextEditingController();
  bool _busy = false;
  String _status = 'Enter the base URL of your deployed API, then check the connection.';
  List<dynamic> _rooms = [];

  @override
  void initState() {
    super.initState();
    _urlController.text = const String.fromEnvironment('API_BASE_URL', defaultValue: 'http://10.0.2.2:8000');
  }

  @override
  void dispose() {
    _urlController.dispose();
    super.dispose();
  }

  Uri? _endpoint(String path) {
    final base = _urlController.text.trim().replaceAll(RegExp(r'/+$'), '');
    final uri = Uri.tryParse('$base$path');
    if (uri == null || !uri.hasScheme || uri.host.isEmpty || !{'http', 'https'}.contains(uri.scheme)) return null;
    return uri;
  }

  Future<void> _checkServer() async {
    final uri = _endpoint('/health');
    if (uri == null) {
      setState(() => _status = 'Please enter a valid URL such as https://your-api.example.com');
      return;
    }
    setState(() { _busy = true; _status = 'Checking server…'; });
    try {
      final response = await http.get(uri).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        setState(() => _status = 'Server reachable: ${response.body}');
      } else {
        setState(() => _status = 'Server replied with HTTP ${response.statusCode}.');
      }
    } catch (e) {
      setState(() => _status = 'Connection failed. Check the URL, internet access, and server status.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _loadRooms() async {
    final uri = _endpoint('/v1/rooms');
    if (uri == null) {
      setState(() => _status = 'Please enter a valid server URL first.');
      return;
    }
    setState(() { _busy = true; _status = 'Loading rooms…'; });
    try {
      final response = await http.get(uri).timeout(const Duration(seconds: 10));
      if (response.statusCode != 200) throw Exception('HTTP ${response.statusCode}');
      final data = jsonDecode(response.body);
      if (data is! List) throw const FormatException('Unexpected room list response');
      setState(() { _rooms = data; _status = 'Loaded ${data.length} room(s) from the server.'; });
    } catch (_) {
      setState(() => _status = 'Could not load rooms. Check server URL and API status.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Server Connection')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Connect this app to the Rudra Chat API. For a real phone, use a reachable HTTPS server URL; 10.0.2.2 works only from the Android emulator to the host computer.', style: TextStyle(color: _muted, height: 1.4)),
      const SizedBox(height: 16),
      TextField(controller: _urlController, keyboardType: TextInputType.url, autocorrect: false, decoration: const InputDecoration(labelText: 'API base URL', hintText: 'https://your-api.example.com', border: OutlineInputBorder())),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: _busy ? null : _checkServer, icon: const Icon(Icons.health_and_safety), label: const Text('Check server')),
      const SizedBox(height: 8),
      OutlinedButton.icon(onPressed: _busy ? null : _loadRooms, icon: const Icon(Icons.meeting_room_outlined), label: const Text('Load online rooms')),
      const SizedBox(height: 16),
      Card(child: Padding(padding: const EdgeInsets.all(14), child: Text(_status))),
      const SizedBox(height: 12),
      if (_rooms.isNotEmpty) ...[
        const Text('Rooms from server', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 8),
        for (final item in _rooms)
          Card(child: ListTile(leading: const Icon(Icons.meeting_room, color: _gold), title: Text('${item['title'] ?? 'Untitled room'}'), subtitle: Text('ID: ${item['id'] ?? '—'} · ${item['room_type'] ?? 'party'}'))),
      ],
      const SizedBox(height: 16),
      const Text('This screen checks the API and reads room listings only. Authentication, real-time chat, voice, and production security are not yet connected.', style: TextStyle(color: _muted, fontSize: 12, height: 1.4)),
    ]),
  );
}

class QuickTile extends StatelessWidget {
  const QuickTile({super.key, required this.icon, required this.title});
  final IconData icon;
  final String title;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(vertical: 17, horizontal: 5),
    decoration: BoxDecoration(color: _panel, border: Border.all(color: const Color(0xFF343752)), borderRadius: BorderRadius.circular(15)),
    child: Column(children: [
      Icon(icon, color: _gold, size: 25),
      const SizedBox(height: 8),
      Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11)),
    ]),
  );
}

class RoomCard extends StatelessWidget {
  const RoomCard({super.key, required this.icon, required this.title, required this.subtitle});
  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(13),
    decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(17), border: Border.all(color: const Color(0xFF343752))),
    child: Row(children: [
      Container(
        width: 53, height: 53,
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(13), gradient: const LinearGradient(colors: [Color(0xFF46366E), Color(0xFF242A4B)])),
        child: Icon(icon, color: _gold, size: 27),
      ),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Text(subtitle, style: const TextStyle(color: _muted, fontSize: 11)),
      ])),
      const Icon(Icons.chevron_right, color: _muted),
    ]),
  );
}

class PartyScreen extends StatefulWidget {
  const PartyScreen({super.key});

  @override
  State<PartyScreen> createState() => _PartyScreenState();
}

class _PartyScreenState extends State<PartyScreen> {
  final Set<int> _occupied = {0, 1, 4, 7, 9};
  final _chatController = TextEditingController();
  final List<String> _messages = ['Jasmine: Welcome everyone!', 'Rudra Star: Ready for a fun quiz?', 'Aman: Let’s go!'];

  @override
  void dispose() {
    _chatController.dispose();
    super.dispose();
  }

  void _claimSeat() {
    final free = List.generate(16, (i) => i).where((i) => !_occupied.contains(i)).firstOrNull;
    if (free == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('All 16 demo seats are occupied.')));
      return;
    }
    setState(() => _occupied.add(free));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Demo seat ${free + 1} reserved. Voice is not connected.')));
  }

  @override
  Widget build(BuildContext context) => ScreenFrame(
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const BrandHeader(showBalance: false),
      const SectionHeading('Late Night Lounge'),
      const Text('Room ID 9566958 · Host: Rudra Star', style: TextStyle(color: _muted, fontSize: 12)),
      const SizedBox(height: 14),
      Container(
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), border: Border.all(color: const Color(0xFF484264)), gradient: const RadialGradient(colors: [Color(0xFF3B315F), Color(0xFF1B1E34)])),
        child: Column(children: [
          const CircleAvatar(radius: 28, backgroundColor: _gold, child: Icon(Icons.workspace_premium, color: _navy, size: 28)),
          const SizedBox(height: 6),
          const Text('Rudra Star', style: TextStyle(fontWeight: FontWeight.bold)),
          const Text('Room Host', style: TextStyle(color: _muted, fontSize: 11)),
          const SizedBox(height: 14),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: 16,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, mainAxisSpacing: 8, crossAxisSpacing: 8, childAspectRatio: .85),
            itemBuilder: (context, i) {
              final active = _occupied.contains(i);
              final names = {0: 'Rudra', 1: 'Jasmine', 4: 'Aman', 7: 'Maya', 9: 'Guest'};
              return Container(
                decoration: BoxDecoration(color: _panel2, borderRadius: BorderRadius.circular(12), border: Border.all(color: active ? _violet : const Color(0xFF454866))),
                padding: const EdgeInsets.all(4),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(active ? Icons.mic : Icons.add_circle_outline, color: active ? _gold : _muted, size: 20),
                  const SizedBox(height: 4),
                  Text(active ? (names[i] ?? 'Guest') : 'Seat ${i + 1}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10)),
                ]),
              );
            },
          ),
        ]),
      ),
      const SizedBox(height: 12),
      FilledButton.icon(
        style: FilledButton.styleFrom(backgroundColor: _gold, foregroundColor: _navy),
        onPressed: _claimSeat,
        icon: const Icon(Icons.mic),
        label: const Text('Take a seat (demo)'),
      ),
      const SizedBox(height: 8),
      OutlinedButton.icon(
        onPressed: () => _showNotice(context, 'Live voice is not connected in this prototype.'),
        icon: const Icon(Icons.volume_up),
        label: const Text('Connect voice'),
      ),
      const SectionHeading('Room chat'),
      Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFF343752))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          for (final msg in _messages) Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Text(msg, style: const TextStyle(fontSize: 12))),
          Row(children: [
            Expanded(child: TextField(controller: _chatController, decoration: const InputDecoration(hintText: 'Write a message…', isDense: true))),
            IconButton(onPressed: () {
              final value = _chatController.text.trim();
              if (value.isEmpty) return;
              setState(() => _messages.add('You: $value'));
              _chatController.clear();
            }, icon: const Icon(Icons.send, color: _gold)),
          ]),
        ]),
      ),
    ]),
  );
}

class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int? _selected;
  final _answers = const ['Venus', 'Mars', 'Jupiter', 'Mercury'];

  @override
  Widget build(BuildContext context) => ScreenFrame(
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const BrandHeader(showBalance: false),
      const SectionHeading('Quiz Arena'),
      const Chip(label: Text('DEMO MATCH · QUESTION 1 OF 10')),
      const SizedBox(height: 10),
      const Text('General Knowledge', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 14),
      Container(
        padding: const EdgeInsets.all(17),
        decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFF343752))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Which planet is known as the Red Planet?', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 14),
          for (int i = 0; i < _answers.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 9),
              child: SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    alignment: Alignment.centerLeft,
                    backgroundColor: _selected == i ? const Color(0xFF443A35) : _panel2,
                    side: BorderSide(color: _selected == i ? _gold : const Color(0xFF484D70)),
                    padding: const EdgeInsets.all(14),
                  ),
                  onPressed: () => setState(() => _selected = i),
                  child: Text('${String.fromCharCode(65 + i)} · ${_answers[i]}'),
                ),
              ),
            ),
          Text(
            _selected == null ? 'Choose an answer. Feedback is simulated in this demo.' : (_selected == 1 ? 'Correct! Demo feedback only.' : 'Not quite — demo feedback only.'),
            style: const TextStyle(color: _muted, fontSize: 12),
          ),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: () => setState(() => _selected = null),
            child: const Text('Try again'),
          ),
        ]),
      ),
      const SectionHeading('Leaderboard'),
      const RoomCard(icon: Icons.looks_one, title: 'Rudra Star', subtitle: '850 points'),
      const SizedBox(height: 8),
      const RoomCard(icon: Icons.looks_two, title: 'Jasmine', subtitle: '720 points'),
      const SizedBox(height: 8),
      const RoomCard(icon: Icons.looks_3, title: 'Aman', subtitle: '640 points'),
    ]),
  );
}

class WalletScreen extends StatelessWidget {
  const WalletScreen({super.key});

  @override
  Widget build(BuildContext context) => ScreenFrame(
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const BrandHeader(showBalance: false),
      const SectionHeading('My Wallet'),
      Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFF50466F)), gradient: const LinearGradient(colors: [Color(0xFF34255C), Color(0xFF20223A)])),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Available Coins · Demo', style: TextStyle(color: _muted)),
          SizedBox(height: 8),
          Text('9,000 🪙', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, color: Color(0xFFF5D58D))),
          SizedBox(height: 6),
          Text('Prototype balance only — no real currency value.', style: TextStyle(color: _muted, fontSize: 11)),
        ]),
      ),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: () => _showNotice(context, 'Payments are not connected yet.'), icon: const Icon(Icons.add_card), label: const Text('Recharge coins')),
      const SizedBox(height: 8),
      OutlinedButton.icon(onPressed: () => _showNotice(context, 'Gift sending is not connected yet.'), icon: const Icon(Icons.card_giftcard), label: const Text('Send a gift')),
      const SectionHeading('Recent activity'),
      const RoomCard(icon: Icons.card_giftcard, title: 'Gift received', subtitle: '+500 demo coins'),
      const SizedBox(height: 8),
      const RoomCard(icon: Icons.redeem, title: 'Gift sent', subtitle: '−100 demo coins'),
      const SizedBox(height: 8),
      const RoomCard(icon: Icons.toll, title: 'Demo top-up', subtitle: '+1,000 demo coins'),
    ]),
  );
}

class AgencyScreen extends StatelessWidget {
  const AgencyScreen({super.key});

  @override
  Widget build(BuildContext context) => ScreenFrame(
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const BrandHeader(showBalance: false),
      const SectionHeading('Agency Center'),
      const HeroCard(title: 'Grow with Rudra Chat', subtitle: 'Manage hosts, track eligible earnings, and review commission statements in one place.'),
      const Row(children: [
        Expanded(child: MetricCard(title: 'Active Hosts', value: '24')),
        SizedBox(width: 10),
        Expanded(child: MetricCard(title: 'This month', value: '12.5K')),
      ]),
      const SectionHeading('Agency options'),
      const RoomCard(icon: Icons.groups, title: 'Host roster', subtitle: 'Demo host list'),
      const SizedBox(height: 8),
      const RoomCard(icon: Icons.bar_chart, title: 'Earnings report', subtitle: 'Preview only'),
      const SizedBox(height: 8),
      const RoomCard(icon: Icons.receipt_long, title: 'Commission statement', subtitle: 'Preview only'),
      const SizedBox(height: 8),
      const RoomCard(icon: Icons.verified_user, title: 'Application & approval', subtitle: 'Admin approval required'),
      const SizedBox(height: 12),
      FilledButton(
        onPressed: () => _showNotice(context, 'Agency applications need a backend and admin approval workflow.'),
        child: const Text('Apply for an agency'),
      ),
    ]),
  );
}

class MetricCard extends StatelessWidget {
  const MetricCard({super.key, required this.title, required this.value});
  final String title;
  final String value;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF343752))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(color: _muted, fontSize: 12)),
      const SizedBox(height: 7),
      Text(value, style: const TextStyle(fontSize: 23, color: Color(0xFFF5D58D), fontWeight: FontWeight.bold)),
      const Text('Demo data', style: TextStyle(color: _muted, fontSize: 10)),
    ]),
  );
}

void _showNotice(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
}
