# Suggested future source layout

After the prototype stage, split `main.dart` into feature modules:

```text
lib/
  app/
    app.dart
    router.dart
    theme/
  core/
    networking/
    auth/
    errors/
    widgets/
  features/
    auth/
    home/
    rooms/
    voice/
    quiz/
    wallet/
    gifts/
    agency/
    host_earnings/
    profile/
    moderation/
  main.dart
```

Use repository/service layers and typed DTOs. Do not put payment, commission, wallet, or authorization rules only in Flutter; those must be enforced on the backend.
