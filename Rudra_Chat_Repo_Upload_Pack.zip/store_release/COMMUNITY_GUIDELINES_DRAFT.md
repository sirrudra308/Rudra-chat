# Rudra Chat Community Guidelines — DRAFT

1. Treat other users respectfully. Harassment, threats, hate, impersonation and targeted abuse are not allowed.
2. Do not share another person's private information without permission.
3. Do not use rooms to scam, manipulate coin transactions, impersonate staff, or misrepresent agency ownership or earnings.
4. Do not post illegal, exploitative, sexually abusive or otherwise prohibited content. Child safety is a priority.
5. Do not spam, automate engagement, manipulate quizzes, or exploit bugs.
6. Use report and block tools for concerning behavior. Do not retaliate against reporters.
7. Hosts and agency owners must follow platform rules, payout terms and identity/eligibility checks where applicable.
8. Moderators may mute, remove, suspend or escalate reports. Serious or repeated violations may result in account restrictions.
9. Appeals: [ADD SUPPORT / APPEAL PROCESS].
10. Safety contact: [ADD SUPPORT EMAIL / URL].

Before launch, connect these rules to working report, block, mute, ban, appeal, escalation and account enforcement flows.
