# Release Status — Rudra Chat

Status: **PREPARATION PACKAGE — NOT STORE-READY**

## Confirmed setup
- Individual publisher preference (legal seller name still needed).
- Play Console and Apple Developer accounts not created yet.
- Login goal: phone OTP + Google/Apple sign-in.
- Voice and payment providers not selected or connected.
- Cash payouts for host/agency earnings intended, but rules are not finalized.
- Confirmed launch preference: global availability target from day one (all supported countries/regions), not India-only. This is a target, not a guarantee; store distribution, laws, provider coverage, payments and payouts may require country exclusions or staged activation. Intended minimum age 18+.
- Support email supplied: sirrudra308@gmail.com.
- No public domain/privacy URL yet.

## Prepared in this package
- Flutter UI starter and clickable HTML prototype.
- Starter FastAPI/PostgreSQL code.
- Store listing, privacy and community-guideline drafts.
- Owner decisions, provider notes, coin/commission proposal and release blockers.

## Not completed / not verified
- Production authentication, authorization and security review.
- Live voice, OTP and Google/Apple sign-in.
- Store billing, verified purchase callbacks, refunds, coin/gift ledger and cash payout integrations.
- Public HTTPS privacy/support/account deletion URLs.
- Final legal terms, payout compliance and country-by-country review for a global launch.
- Signed Android App Bundle and signed iOS archive.
- Developer account verification and store approvals.

Do not submit the current prototype as a finished production service. The existing starter API includes demo routes without full authentication and must not be exposed publicly.
