# Rudra Chat — Store Submission Checklist

## Publisher details — owner must supply
- [ ] Google Play Console developer account active and verified
- [ ] Apple Developer Program membership active
- [ ] Legal publisher name, country and support contact
- [ ] Public HTTPS privacy policy and support URLs
- [ ] Final app name, icon, screenshots and store descriptions
- [ ] Bundle/package IDs approved and unique
- [ ] Signing keys/certificates stored securely by the owner (never send passwords or private keys in chat)

## Product readiness — engineering gates
- [ ] Production authentication and account recovery
- [ ] Account deletion from app and a public request path where required
- [ ] Server-side authorization for every privileged API
- [ ] Live audio SDK configured; mic permission rationale, reconnect and moderation tested
- [ ] 16-seat race-condition/concurrency tests passed
- [ ] Multiplayer quiz state and scoring controlled by server
- [ ] Coin ledger transactional and idempotent; clients cannot write balances
- [ ] Store-compliant digital goods billing and verified purchase callbacks implemented
- [ ] Gift debit/credit, host earnings and agency commissions reconciled and auditable
- [ ] Payout eligibility, KYC/tax/compliance and fraud controls reviewed where relevant
- [ ] Report, block, mute, ban, appeal and admin audit features working
- [ ] Rate limiting, abuse prevention, secrets management, backups and monitoring enabled
- [ ] Privacy/data-safety answers match SDKs and actual network behavior
- [ ] Accessibility, low-network, crash, device and security tests passed

## Google Play
- [ ] Complete store listing, app access instructions and content rating
- [ ] Complete Data safety form accurately
- [ ] Complete target audience / age declarations
- [ ] Complete ads declaration if ads are present
- [ ] Upload signed Android App Bundle (.aab)
- [ ] Meet current testing-track and account-specific requirements shown in Play Console
- [ ] Review policy requirements for user-generated content, voice/chat, billing and financial features

## Apple App Store
- [ ] App Store Connect record and bundle ID created
- [ ] Upload signed archive via Xcode on macOS
- [ ] App Privacy details match all SDKs and data flows
- [ ] Age rating and content rights completed
- [ ] Review notes and demo account supplied if needed
- [ ] In-app purchase products configured and reviewed where applicable
- [ ] Account deletion and user-generated-content moderation reviewed

## Release evidence
- [ ] Test report and known-issues list
- [ ] Staging sign-off and rollback plan
- [ ] Support escalation and incident response contacts
- [ ] Legal review of terms, privacy, virtual currency and any payout/agency programme
