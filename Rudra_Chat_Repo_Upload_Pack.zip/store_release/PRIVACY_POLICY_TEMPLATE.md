# Rudra Chat Privacy Policy — TEMPLATE ONLY

**Do not publish until every bracketed field is completed and the policy is reviewed for the actual app and jurisdictions.** This is a drafting aid, not legal advice.

Effective date: [DATE]
Controller / publisher: [LEGAL ENTITY OR RESPONSIBLE PERSON]
Contact: sirrudra308@gmail.com (owner-supplied support email; confirm it is monitored and use it for privacy requests before publishing)
Address (if required): [BUSINESS ADDRESS]

## Information we collect
Describe only data actually collected by the shipped app, such as account/profile details, user-generated content, room and moderation activity, support requests, purchase records, device/app diagnostics, and voice-session metadata. State whether audio is recorded or stored; do not claim it is not recorded unless verified technically and contractually.

## How we use information
Explain account operation, room and voice delivery, safety/moderation, customer support, payment reconciliation, fraud prevention, legal compliance, and service improvement. Identify any advertising or analytics purposes if used.

## Voice and user content
Explain when microphone access is requested, how live audio is transmitted, whether any recording/transcription occurs, retention periods, and controls. Obtain consent and comply with applicable law before recording or processing voice content.

## Coins, gifts and payments
Explain which provider processes purchases, what purchase records are received, what virtual coins/gifts mean, refund handling, and whether any host/agency payout programme exists. Do not describe coins as cash or promise earnings unless the programme is legally reviewed and actually implemented.

## Sharing
List each category of service provider (hosting, voice/RTC, payment, analytics, support) and what data it receives. Describe disclosures required by law and any user-directed sharing. Do not claim data is never shared if vendors process it.

## Retention and deletion
Specify retention periods or criteria for account data, support tickets, safety reports, financial records and backups. Provide a working in-app account deletion route and a public web request route if applicable; explain any legally required financial-record retention.

## Security
Describe safeguards accurately without promising absolute security.

## Children and age requirements
Intended minimum age currently selected by the owner: 18+. Implement and test age gating and store age/content declarations to match the shipped app and applicable law. Do not publish this policy until the legal publisher details, address if required, effective date, collection practices, retention and actual vendors are completed.

## International transfers
Describe transfer locations and safeguards if data leaves the user's country.

## User rights and choices
Explain applicable access, correction, deletion, objection, consent withdrawal and complaint rights, plus how to contact the privacy team.

## Changes and contact
Explain how policy updates are announced and provide the contact details above.
