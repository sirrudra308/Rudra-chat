# Rudra Chat — Provider Selection Notes

**Nothing is connected yet. These are candidates to evaluate, not endorsements or active integrations.**

## Voice rooms (Flutter + Android + iOS)

### Candidate A: LiveKit Cloud / self-hosted LiveKit
- Official Flutter SDK supports cross-platform real-time audio/video and can connect to LiveKit Cloud or a self-hosted server.
- Good fit if control, open-source infrastructure options and a clear room/token architecture are priorities.
- Requires server-generated short-lived access tokens, room authorization, moderation integration, region/privacy review, and load/cost testing.
- Docs: https://docs.livekit.io/transport/sdk-platforms/flutter/

### Candidate B: Agora RTC
- Official Flutter voice SDK supports joining channels and publishing/subscribing to audio.
- Good fit if managed RTC service and a vendor-operated real-time network are priorities.
- Requires an Agora project, app configuration, server-generated tokens, vendor terms/privacy review, and cost/load testing. Never put a server certificate/secret in the mobile app.
- Docs: https://docs.agora.io/en/realtime-media/rtc/voice-quickstart/flutter

### Recommendation for the first technical spike
Prototype the same 16-seat party-room audio flow with **LiveKit and Agora** only if time/budget allows; compare latency on weak mobile networks, Android/iOS background behavior, mute enforcement, moderation, regional coverage, per-minute cost and operational complexity. If choosing one before testing, LiveKit is a reasonable architecture-first candidate, but final choice should follow a small device test and current pricing review. Do not claim either provider is configured in the app yet.

## Billing for in-app coin packs
- **Google Play:** use Google Play Billing for virtual currency unless the app qualifies for a current documented exception or enrolled regional program. Official policy: https://support.google.com/googleplay/android-developer/answer/10281818
- **Apple:** implement the appropriate StoreKit in-app purchase path for virtual goods according to current App Review Guidelines and storefront-specific rules. Official guidelines: https://developer.apple.com/app-store/review/guidelines/
- Provider choice must be based on store rules, supported countries, tax/refund handling, webhook verification, reconciliation, and actual fees. Do not assume a standard third-party checkout can sell in-app coins in every storefront.

## Cash payouts for hosts/agencies
This is separate from coin purchases. Before selecting a payout provider, get qualified advice on countries, KYC/identity verification, tax reporting, sanctions, minors, disputes, chargebacks, fraud, and whether the platform's business model is permitted. The account and payout programme must be controlled by a legally eligible adult/operator. No payout provider has been selected or connected.
