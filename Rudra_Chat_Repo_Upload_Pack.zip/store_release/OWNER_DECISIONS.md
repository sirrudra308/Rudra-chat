# Rudra Chat — Confirmed Owner Inputs

Last updated: 2026-10-25

## Confirmed
- Publisher preference: Individual account (exact legal name still required by each store).
- Google Play Console: not created yet.
- Apple Developer Program: not created yet.
- Login target: phone OTP + Google/Apple sign-in.
- Voice provider: not selected; credentials do not exist / have not been supplied.
- Payment provider: not selected; credentials do not exist / have not been supplied.
- Host/agency earnings: intended to be withdrawable money.
- Launch ambition: global.
- Intended audience: 18+.
- Support email supplied: sirrudra308@gmail.com.
- Website/privacy domain: none yet.
- Coin / commission rules: not finalized.

## Important account responsibility
Store memberships, identity verification, contracts, payment processing and payouts must be controlled by the legally eligible account holder. If the project owner is under the required age, a parent/guardian or other legally responsible adult must handle the account, contract, and financial setup transparently; do not enter a false age or bypass verification. Google says Play Console registration requires age 18+ and currently lists a US$25 one-time registration fee. Apple lists a US$99 annual Developer Program fee and requires the legal seller name for individual accounts. Confirm current requirements and local pricing during enrollment.

## Unresolved release decisions
1. Exact legal publisher name and country. Do not use an alias if the store asks for legal name.
2. Public HTTPS website/privacy URL and support URL. The email alone does not replace the required public privacy policy.
3. Voice provider, cloud region, data processing terms, retention and cost limits.
4. Store billing design for coin packs in each storefront and eligible region.
5. Legal review of withdrawable host/agency earnings, KYC, taxes, refunds, disputes, sanctions and cross-border payouts.
6. Final coin pack prices, gift costs, payout threshold, commission percentages and refund/chargeback treatment.
7. Global launch country list. “Global” should not be switched on until each country, payout rail and legal requirements have been reviewed.

Never send passwords, OTPs, private signing keys, payment secrets or identity documents in chat.
