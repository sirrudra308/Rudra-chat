# Rudra Chat — Coins, Gifts, Earnings & Commission (DRAFT)

**Status: proposal only — not approved for production, not legal/accounting advice.** Do not display cash-earning promises or enable cashouts until the responsible adult/operator and qualified advisers approve the rules and implementation.

## 1. Suggested product model
- Coins are closed-loop virtual items used only inside Rudra Chat for gifts and supported app features. They are not cryptocurrency, bank deposits, or automatically redeemable cash.
- A coin purchase is fulfilled only after a verified store/provider transaction callback. The client must never set its own coin balance.
- Keep separate ledgers for purchased coins, promotional coins, gifts spent, host accruals, agency commissions, refunds, reversals and payout liabilities. Use immutable entries and unique idempotency references.
- Never allow users to transfer purchased coins to other users as cash, or describe coins as cash-equivalent, unless the legal/store/payment model has been reviewed and approved.

## 2. Illustrative commission starting point (not final)
A simple draft to discuss with an adult operator and accountant is to calculate a distributable pool from **eligible net gift revenue**, then split it provisionally as follows:
- Host pool: 70%
- Agency commission pool: 10%
- Platform pool: 20%

These are discussion figures only. They must not be hard-coded until the parties agree what “eligible net gift revenue” means and the impact of store fees, taxes, refunds, chargebacks, promotional coins, fraud, regional pricing and agency/host eligibility is understood. The percentages above add to 100% of the defined distributable pool; they are not percentages of gross customer payment unless explicitly defined that way in signed terms.

## 3. Suggested accounting sequence
1. Record a verified purchase with store transaction ID and currency/price.
2. Credit the purchased coin pack exactly once.
3. On a gift, debit the sender's eligible coin balance atomically.
4. Record the gift event and calculate host/agency accruals on the server from a versioned ruleset.
5. Reverse or adjust linked entries for refunds, chargebacks, confirmed fraud or moderation decisions, with a full audit trail.
6. Only mark an earning “payable” after policy checks, cooling-off period if adopted, minimum threshold, identity/tax checks where legally required, and account review.
7. Payout must use a vetted provider and be reconciled by provider transaction ID.

## 4. Questions to settle before implementation
- What coin pack prices will each store and country show?
- What are each gift's coin cost and the rules for promotional/free coins?
- Are host earnings based on coins spent, gift revenue, or another measurable basis?
- Does the agency commission come out of the host pool or from a separate platform pool? The proposal above assumes separate portions of the distributable pool.
- Minimum payout and payout frequency?
- What happens on refund, chargeback, banned host, inactive agency, disputed ownership, duplicate accounts or fraudulent gifts?
- Which countries are supported for cashout and which payout currencies?
- What KYC, age, tax reporting, sanctions and record-retention duties apply in each market?

## 5. Store-policy caution
Google Play generally requires Google Play Billing for digital goods and virtual currency sold in Play-distributed apps, unless a documented policy exception/program applies. Apple's rules differ by product type, storefront and region and must be checked at submission. Do not implement a generic external payment button for in-app coins without a policy review. Host/agency payouts are a separate legal and operational workstream from selling virtual coins.

## 6. Previously discussed coin ratio — confirm before use
A prior draft used **₹100 = 90,000 coins** as a proposed rate. This is not yet an approved pack price and should be confirmed against store fees, taxes, refunds, region pricing and the product's unit economics before being shown to users.
