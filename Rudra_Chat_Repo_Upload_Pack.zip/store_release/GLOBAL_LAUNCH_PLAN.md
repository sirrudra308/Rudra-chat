# Rudra Chat — Global Launch Plan

## Product decision
**Target:** prepare Rudra Chat for release to all countries/regions supported by the app stores and selected service providers from day one, rather than making India the only launch market. This is a goal, not a promise of universal availability. Each country must pass the readiness checks below.

## Launch features in scope
- Android and iOS apps
- Phone OTP and Google/Apple sign-in
- Party voice rooms with up to 16 mic seats
- Multiplayer quiz room
- Virtual coins and gifts
- Host/agency earnings and payouts, after legal and accounting approval
- 18+ product policy, report/block/mute tools, moderation and support

## Country readiness matrix (must be completed before enabling a country)
For every country/region, record: app-store availability; local legal review; voice provider availability and latency; OTP delivery; payment methods/currency; tax/refund rules; payout availability and KYC/tax requirements; privacy/data-transfer requirements; language/support coverage; age/content rating; incident-response coverage. Keep separate allowlists for coin purchases and cash payouts.

## Required release sequence
1. **Build and security:** replace demo auth/routes, enforce server-side authorization, protect secrets, test account deletion, add audit logs and monitoring.
2. **Provider integration:** select and configure voice, OTP, billing, analytics and payout services; verify production credentials and regional availability.
3. **Coins and earnings:** define the purchased-coin ledger, gifts, refunds/chargebacks, fees, taxes, host earnings, agency commission and payout reconciliation. Do not hard-code the draft split until approved.
4. **Trust and safety:** reporting, blocking, muting, content filtering, moderation staffing/escalation, appeals, emergency response and clear contact details.
5. **Legal and privacy:** publish accurate privacy policy, terms, community rules, support and account-deletion pages on a public HTTPS domain; review each target jurisdiction.
6. **Testing:** device testing on Android/iOS, load and regional latency tests, abuse/security testing, billing/refund tests and payout reconciliation in a test environment.
7. **Store review:** prepare accurate store listings, age ratings, disclosures, screenshots, reviewer notes and signed release builds.
8. **Global activation:** enable only countries that passed the readiness matrix; monitor crashes, abuse, costs and payment failures and pause a country if a critical gate fails.

## Important constraints
- App stores and local laws may require certain countries to be excluded or enabled later.
- A global app listing does not guarantee OTP, voice, purchases or payouts work in every country.
- Virtual coins and digital goods must follow the current store billing rules and any applicable exceptions/programs.
- Cash earnings and cross-border payouts require professional legal/accounting review and provider approval.
- If the project owner is under the required age, a legally eligible adult/authorized business must be responsible for store accounts, contracts, payment/payout accounts and identity checks. Never bypass age or identity verification.
- The current project is a starter package, not a production-ready or store-approved application.
