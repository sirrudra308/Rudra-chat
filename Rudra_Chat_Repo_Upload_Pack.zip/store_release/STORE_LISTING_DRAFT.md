# Rudra Chat — Store Listing Draft (review before publishing)

## App name
Rudra Chat

## Short description (draft)
Join voice rooms, meet communities, play quizzes and enjoy virtual gifts.

## Full description (draft)
Welcome to Rudra Chat, a community app concept for voice rooms, social interaction and casual quiz games.

Planned features:
- Party rooms with up to 16 speaker seats
- Host and moderator controls
- Gaming rooms and multiplayer quiz experiences
- Virtual gifts and coin balance history
- Agency and host management tools (where enabled)
- User reporting, blocking and safety controls

Availability of features may vary by release. Coins and virtual gifts are in-app digital items and do not represent cash unless an explicitly approved payout program and its terms say otherwise. Do not publish this description until all listed features are implemented and tested.

## Store listing assets to prepare
- App icon: 512×512 PNG for Google Play; Apple app icon asset set for iOS
- Phone screenshots showing real, implemented app screens
- Feature graphic: 1024×500 for Google Play (if applicable)
- Support URL and privacy-policy URL on a public HTTPS website
- Developer contact email
- Accurate age rating, content questionnaire and data disclosures
