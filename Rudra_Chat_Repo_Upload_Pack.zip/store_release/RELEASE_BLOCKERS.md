# Release Blockers — Rudra Chat

## Blocking store submission
- [ ] Production-grade authentication: phone OTP and Google/Apple sign-in, account linking and recovery.
- [ ] Server-side roles and authorization on every protected API. Current starter API contains demo routes and must not be exposed publicly as-is.
- [ ] Public HTTPS website with complete privacy policy, terms, support and account-deletion instructions.
- [ ] Real voice integration with server-issued tokens and 16-seat concurrency testing.
- [ ] Server-authoritative quiz match state and anti-cheat.
- [ ] Compliant store billing, verified purchase callbacks, refunds and reconciliation.
- [ ] Approved coin/gift/commission rules and complete immutable accounting ledger.
- [ ] Legal/compliance review for withdrawable earnings and global payouts.
- [ ] User-generated content safety: report, block, mute, moderation response process, appeals and contact information. Apple explicitly requires filtering, reporting, blocking and published contact information for UGC apps.
- [ ] Account deletion flow and privacy/data-safety declarations matching actual SDK behavior.
- [ ] Production secrets management, database migrations, backups, monitoring, rate limits, penetration/security review and incident response.
- [ ] Store screenshots, icons, age/content declarations, support URLs, test credentials and review notes.
- [ ] Signed Android App Bundle and signed iOS archive built and tested on real devices.
- [ ] Store developer accounts approved and all current account-specific testing requirements completed.

## Current truth
This is a starter project and documentation package. It is not yet a release candidate. No live voice, OTP, store billing, real-money payout, production domain, store account or signed store build is configured or verified.


## Additional global-launch gates
- [ ] Build a country/region matrix for app availability, voice-provider coverage, OTP delivery, supported currencies, taxes, sanctions/restrictions and customer support. Do not promise service in a country until checked.
- [ ] Decide which countries can buy coins and which countries can receive host/agency payouts; these may be different lists.
- [ ] Review local rules for digital goods, consumer refunds, privacy/data transfers, age ratings, user-generated content, tax reporting and cash earnings in every launch jurisdiction.
- [ ] Prepare localized store text, support workflows, safety reporting and privacy disclosures for the countries actually supported.
- [ ] Run load, latency, abuse, moderation and payout-reconciliation tests across regions before enabling worldwide traffic.
- [ ] Have a legally eligible adult/authorized business operator handle developer-store enrollment, contracts, payment/payout accounts, identity checks and financial/legal decisions if the project owner is under the required age. Do not bypass age or identity verification.

Global availability should be enabled only where all required services and legal checks pass. A worldwide target does not mean every country can be activated simultaneously.
