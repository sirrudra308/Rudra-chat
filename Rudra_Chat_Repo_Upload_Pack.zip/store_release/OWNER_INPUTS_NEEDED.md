# Rudra Chat — Owner Inputs / Confirmed Status

Confirmed by owner:
- Publisher preference: individual
- Google Play Console: not yet created
- Apple Developer Program: not yet created
- Login goal: phone OTP + Google/Apple sign-in
- Voice provider: needs selection
- Payment provider: needs selection
- Earnings: intended to be withdrawable money
- Launch ambition: global
- Target age: 18+
- Support email: sirrudra308@gmail.com
- Website/privacy domain: not available yet
- Coin and commission rules: need decision

## Still needed (do not send secrets here)
1. Exact legal publisher name/country for store account forms.
2. A public HTTPS domain for privacy policy, terms, support and account deletion.
3. Adult legal/account owner responsible for developer agreements and money/payout programme if the project owner is under the required age. Do not bypass age or identity checks.
4. Voice provider decision after test/pricing/privacy comparison.
5. Store billing implementation decision for virtual coin packs.
6. Final pack prices, gift costs, commission basis/percentages, refund rules and payout thresholds.
7. Country-by-country launch and payout eligibility list; do not activate “global” by default.
8. Final logo/icon and screenshots.

Never share passwords, OTPs, private signing keys, API secrets, payment credentials or identity documents in chat.
