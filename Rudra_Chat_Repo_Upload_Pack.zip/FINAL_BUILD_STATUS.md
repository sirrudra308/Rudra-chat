# Rudra Chat — current build status

## Delivered in this package
- Clickable HTML app UI prototype
- Flutter UI starter source for Android/iOS
- FastAPI + PostgreSQL development backend scaffold
- 16-seat room model and seat-claim endpoint
- Wallet balance read-only endpoint and ledger table foundation
- PostgreSQL schema foundation
- Docker Compose local development setup
- Static admin console preview

## Not yet production-ready
- Real login / OTP and server-enforced permissions
- Voice chat / RTC provider and reconnect handling
- Payment provider integration and verified webhooks
- Gift sending, coin debit/credit transactions, host earnings and agency commission engine
- Payout/KYC/compliance workflows
- Production migrations, automated tests, monitoring, abuse controls and security audit
- Android/iOS release signing and store publishing

## Launch prerequisites
1. Confirm legal business entity, app policies and age/safety requirements.
2. Choose voice provider and payment provider; complete their accounts and keys outside source control.
3. Finalize coin pricing, gift pricing, host share, agency share, platform share and payout thresholds.
4. Add authentication and authorization before internet exposure.
5. Test concurrency, payment reconciliation, moderation and recovery; then deploy staging.
6. Produce signed release builds and complete store review.
